<?php
//process.php
if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {//Check it is coming from a form
    
		//mysql credentials
    $mysql_host = "localhost";
    $mysql_username = "anett28";
    $mysql_password = "Anett1991";
    $mysql_database = "cats";
	
	//delcare PHP variables
	
	$Name = $_POST["Name"];
	$HairColor = $_POST["hairColor"];
	$Coloreyes = $_POST["eyeColor"];
	$Birthday = $_POST["birthday"];
	$Gender = $_POST["Gender"];
	$Pattern = $_POST["pattern"];
	
	//Open a new connection to the MySQL server
	//see https://www.sanwebe.com/2013/03/basic-php-mysqli-usage for more info
	$mysqli = new mysqli($mysql_host, $mysql_username, $mysql_password, $mysql_database);
	
	//Output any connection error
	if ($mysqli->connect_error) {
		die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
	}   
	
		$statement = $mysqli->prepare("INSERT INTO cats (Name, HairColor, Coloreyes, Birthday, Gender, Pattern) VALUES(?, ?, ?, ?, ?, ?)"); //prepare sql insert query
		//bind parameters for markers, where (s = string, i = integer, d = double,  b = blob)
		$statement->bind_param('ssssss', $Name, $HairColor, $Coloreyes, $Birthday, $Gender, $Pattern); //bind value
		if($statement->execute())
			{
				//print output text
				echo nl2br("Your cats name is"." ". $Name . "! and has the fur color of ". $HairColor.  "with ". $Coloreyes ."eyes."."A" . $Gender . " cat born on". $Birthday . "with ". $Pattern . "pattern", false);
			}
			else{
					print $mysqli->error; //show mysql error if any 
				}

         }
else{
    echo ("error");
    }         
?>